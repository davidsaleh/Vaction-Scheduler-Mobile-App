package com.example.d308mobiledevelopmentapplicationandroid.UI;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.d308mobiledevelopmentapplicationandroid.R;
import com.example.d308mobiledevelopmentapplicationandroid.Database.Repository;
import com.example.d308mobiledevelopmentapplicationandroid.entities.Excursion;
import com.example.d308mobiledevelopmentapplicationandroid.entities.Vacation;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Project: Vacation Scheduler
 * Package: com.example.d308mobiledevelopmentapplicationandroid.Dao
 * <p>
 * User: Dawood Ahmed
 * Date: 6/14/2023
 * Time: 4:04 PM
 * <p>
 * Created with Android Studio
 * To change this template use File | Settings | File Templates.
 */
public class VacationDetails extends AppCompatActivity {
    EditText editTitle;
    EditText editHotel;

    EditText editStartDate;

    EditText editEndDate;
    String title;
    String hotel;

    String startDate;

    String endDate;
    int id;
    Vacation vacation;
    Vacation currentVacation;
    int numExcursions;
    Repository repository;
     ExcursionAdapter excursionAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vacation_details);
        editTitle = findViewById(R.id.vacationtitle);
        editHotel = findViewById(R.id.vacationhotel);
        editStartDate = findViewById(R.id.vacationstartDate);
        editEndDate = findViewById(R.id.vacationendDate);
        id = getIntent().getIntExtra("id", -1);
        title = getIntent().getStringExtra("title");
        hotel = getIntent().getStringExtra("hotel");
        startDate = getIntent().getStringExtra("startDate");
        endDate = getIntent().getStringExtra("endDate");
        editTitle.setText(title);
        editHotel.setText(hotel);
        editStartDate.setText(startDate);
        editEndDate.setText(endDate);
        repository = new Repository(getApplication());
        RecyclerView recyclerView = findViewById(R.id.partrecyclerview);
        repository = new Repository(getApplication());
        excursionAdapter = new ExcursionAdapter(this);
        recyclerView.setAdapter(excursionAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        List<Excursion> filteredExcursions = new ArrayList<>();
        for (Excursion e : repository.getAllExcursions()) {
            if (e.getVacationID() == id) filteredExcursions.add(e);
        }
        excursionAdapter.setExcursions(filteredExcursions);
        Button button = findViewById(R.id.savevacation);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String format = "MM/dd/yyyy";
                boolean isValidStartDate = isValidDateFormat( editStartDate.getText().toString(), format);
                if (isValidStartDate) {
                    System.out.println("Valid date format");
                } else {
                    System.out.println("Invalid date format");
                }
                boolean isValidEndDate = isValidDateFormat( editEndDate.getText().toString(), format);
                if (isValidStartDate) {
                    System.out.println("Valid date format");
                } else {
                    System.out.println("Invalid date format");
                }
                if(!isValidStartDate){
                    Toast.makeText(VacationDetails.this,"Please Enter Correct Start Date",Toast.LENGTH_LONG).show();
                }
                else if(!isValidEndDate){
                    Toast.makeText(VacationDetails.this,"Please Enter Correct End Date",Toast.LENGTH_LONG).show();
                }
                else{
                    SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
                    Date date1,date2;
                    try {

                        date1 = formatter.parse( editStartDate.getText().toString());
                         date2 = formatter.parse(editEndDate.getText().toString());
                    } catch (ParseException e) {
                        throw new RuntimeException(e);
                    }
                    if(date1.getTime()>date2.getTime()==true) {
                        Toast.makeText(VacationDetails.this,"Please Enter Correct End Date",Toast.LENGTH_LONG).show();
                    }else{
                     if (id == -1) {
                         String title= editTitle.getText().toString();
                         String editStart= editStartDate.getText().toString();
                         String editEnd= editEndDate.getText().toString();
                         Toast.makeText(VacationDetails.this,title+" "+" Vacation starts on " +editStart +" and ending on "+ editEnd,Toast.LENGTH_LONG).show();
//                         Toast.makeText(VacationDetails.this,"Vacation Saved Successfully",Toast.LENGTH_LONG).show();
                         vacation = new Vacation(0, editTitle.getText().toString(), editHotel.getText().toString(), editStartDate.getText().toString(), editEndDate.getText().toString());
                         repository.insert(vacation);
                     } else {
                         String title= editTitle.getText().toString();
                         String editStart= editStartDate.getText().toString();
                         String editEnd= editEndDate.getText().toString();
                         Toast.makeText(VacationDetails.this,title+" "+" Vacation starts on " +editStart +" and ending on "+ editEnd,Toast.LENGTH_LONG).show();
                         vacation = new Vacation(id, editTitle.getText().toString(), editHotel.getText().toString(), editStartDate.getText().toString(), editEndDate.getText().toString());
                         repository.update(vacation);
                     }
                 }
                }
            }
        });
        FloatingActionButton fab = findViewById(R.id.floatingActionButton2);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(VacationDetails.this, ExcursionDetails.class);
                intent.putExtra("vacID", id);
                startActivity(intent);
            }
        });

        EditText searchInput = findViewById(R.id.search_edittext);
        searchInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }


            @Override
            public void afterTextChanged(Editable editable) {
                String query = editable.toString().toLowerCase();
                List<Excursion> filteredExcursions = new ArrayList<>();
                for (Excursion e : repository.getAllExcursions()) {
                    // Add the condition to check if the excursion title contains the search query
//                    if ( e.getExcursionName().trim().toLowerCase().contains(query)) {
                    if (e.getVacationID() == id && e.getExcursionName().trim().toLowerCase().contains(query)) {
                        filteredExcursions.add(e);
                    }
                }
                excursionAdapter.setExcursions(filteredExcursions);
                excursionAdapter.notifyDataSetChanged();
            }
        });

    }

    @Override
    protected void onResume() {

        super.onResume();
        RecyclerView recyclerView = findViewById(R.id.partrecyclerview);
//        final ExcursionAdapter excursionAdapter = new ExcursionAdapter(this);
        recyclerView.setAdapter(excursionAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        List<Excursion> filteredExcursions = new ArrayList<>();
        for (Excursion e : repository.getAllExcursions()) {
            if (e.getVacationID() == id)
                filteredExcursions.add(e);
        }
        excursionAdapter.setExcursions(filteredExcursions);

        //Toast.makeText(vacationDetails.this,"refresh list",Toast.LENGTH_LONG).show();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.deleteexcursion, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.deletevacation: {
                for (Vacation vac : repository.getAllVacations()) {
                    if (vac.getVacationID() == id) currentVacation = vac;
                }

                numExcursions = 0;
                for (Excursion Excursion : repository.getAllExcursions()) {
                    if (Excursion.getVacationID() == id) ++numExcursions;
                }

                if (numExcursions == 0) {
                    repository.delete(currentVacation);
                    Toast.makeText(VacationDetails.this, currentVacation.getVacationTitle() + " was deleted", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(VacationDetails.this, "Can't delete aVacation with Excursions", Toast.LENGTH_LONG).show();
                }
            }
            return true;

            case R.id.sharevacation: {
                if(id!=-1){
                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("text/plain");
                    shareIntent.putExtra(Intent.EXTRA_TEXT, "Title: "+ title+"\n"+"Hotel: "+ hotel+"\n"+"Start Date: "+ startDate+"\n"+"End Date: "+ endDate+"\n"); // Replace "Text to share" with the actual content you want to share

// Verify that there is an app available to handle the share intent
                    if (shareIntent.resolveActivity(getPackageManager()) != null) {
                        // Start the sharing action
                        startActivity(Intent.createChooser(shareIntent, "Share via"));
                    }
                }
            }

            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    public static boolean isValidDateFormat(String input, String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format, Locale.US);
        sdf.setLenient(false);

        try {
            Date date = sdf.parse(input);
            return input.equals(sdf.format(date));
        } catch (ParseException e) {
            return false;
        }
    }
}
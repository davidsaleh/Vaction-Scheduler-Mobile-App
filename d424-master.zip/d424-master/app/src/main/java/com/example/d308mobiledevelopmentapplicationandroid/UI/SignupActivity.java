package com.example.d308mobiledevelopmentapplicationandroid.UI;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.d308mobiledevelopmentapplicationandroid.Database.VacationDatabaseBuilder;
import com.example.d308mobiledevelopmentapplicationandroid.R;
import com.example.d308mobiledevelopmentapplicationandroid.entities.User;

public class SignupActivity extends AppCompatActivity {
    private VacationDatabaseBuilder appDatabase;

    private EditText editTextSignupUsername, editTextSignupPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        appDatabase = VacationDatabaseBuilder.getDatabase(this);

        editTextSignupUsername = findViewById(R.id.editTextSignupUsername);
        editTextSignupPassword = findViewById(R.id.editTextSignupPassword);

        Button buttonSignup = findViewById(R.id.buttonSignup);
        buttonSignup.setOnClickListener(v -> {
            String username = editTextSignupUsername.getText().toString().trim();
            String password = editTextSignupPassword.getText().toString().trim();

            if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
                Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            } else {
                signup(username, password);
            }
        });
    }
    private void signup(String username, String password) {
        User newUser = new User();
        newUser.setUsername(username);
        newUser.setPassword(password);

        AsyncTask.execute(() -> {
            appDatabase.userDao().insert(newUser);
            runOnUiThread(() -> {
                SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putBoolean("isLoggedIn", true);
                editor.apply();
                startActivity(new Intent(this, MainActivity.class));

                // Signup successful, show a message or navigate to the next screen
            });
        });
    }
//    private void signup(String username, String password) {
//        // Implement the signup functionality using Room Database
//        // See Step 5 from the previous response for the implementation
//    }
}

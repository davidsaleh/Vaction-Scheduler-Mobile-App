package com.example.d308mobiledevelopmentapplicationandroid.UI;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.d308mobiledevelopmentapplicationandroid.Database.Repository;
import com.example.d308mobiledevelopmentapplicationandroid.R;
import com.example.d308mobiledevelopmentapplicationandroid.UI.VacationAdapter;
import com.example.d308mobiledevelopmentapplicationandroid.UI.VacationDetails;
import com.example.d308mobiledevelopmentapplicationandroid.entities.Vacation;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputLayout;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class VacationList extends AppCompatActivity {

    private Repository repository;
    private VacationAdapter vacationAdapter;
    private List<Vacation> allVacations;
    private TextInputLayout searchLayout;
    private EditText searchEditText;
    private TextView startDateTextView;
    private TextView endDateTextView;
    private Calendar calendar;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vacation_list);

        RecyclerView recyclerView = findViewById(R.id.vacationrecyclerview);
        vacationAdapter = new VacationAdapter(this);
        recyclerView.setAdapter(vacationAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        repository = new Repository(getApplication());

        allVacations = repository.getAllVacations();

        FloatingActionButton fab = findViewById(R.id.floatingActionButton);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(VacationList.this, VacationDetails.class);
                startActivity(intent);
            }
        });

        // Initialize and set up the search field
        searchLayout = findViewById(R.id.search_layout);
        searchEditText = findViewById(R.id.search_edittext);
        searchEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                filterVacations(editable.toString());
            }
        });

        startDateTextView = findViewById(R.id.start_date_textview);
        endDateTextView = findViewById(R.id.end_date_textview);
        calendar = Calendar.getInstance();

        startDateTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog(startDateTextView);
            }
        });

        endDateTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(VacationList.this,FilterVacationList.class));
            }
        });

        // Display all vacations initially
        vacationAdapter.setVacations(allVacations);
    }

    private void filterVacations(String query) {
        String startDateStr = startDateTextView.getText().toString();
        String endDateStr = endDateTextView.getText().toString();

        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yy", Locale.getDefault());

        Date startDate = null;
        Date endDate = null;

        try {
            startDate = dateFormat.parse(startDateStr);
            endDate = dateFormat.parse(endDateStr);
        } catch (Exception e) {
            e.printStackTrace();
        }

        List<Vacation> filteredList = new ArrayList<>();

        for (Vacation vacation : allVacations) {
            if (vacation.getVacationTitle().toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(vacation);
//                if (startDate != null && endDate != null) {
//
//                    try {
//                        // Define the date format used in the strings
//                        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yy");
//                        // Parse the strings into Date objects
//                        Date vacationStartDate = sdf.parse(vacation.getVacationStartDate());
//                        Date vacationEndDate = sdf.parse(vacation.getVacationEndDate());
//                        if (vacationStartDate != null && vacationEndDate != null) {
//                            if (vacationStartDate.after(startDate) || vacationStartDate.equals(startDate)) {
//                                if (vacationEndDate.before(endDate) || vacationEndDate.equals(endDate)) {
//
//                                }
//                            }
//                        }
//                    } catch (ParseException e) {
//                        e.printStackTrace();
//                    }
//
//
//                } else {
//                    filteredList.add(vacation);
//                }
            }
        }

        vacationAdapter.setVacations(filteredList);
    }

    private void showDatePickerDialog(final TextView dateTextView) {
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
                calendar.set(Calendar.YEAR, year);
                calendar.set(Calendar.MONTH, monthOfYear);
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yy", Locale.getDefault());
                String selectedDate = dateFormat.format(calendar.getTime());
                dateTextView.setText(selectedDate);
                filterVacations(searchEditText.getText().toString());
            }
        };

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                dateSetListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );

        datePickerDialog.show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Update the list when the activity is resumed
        allVacations = repository.getAllVacations();
        filterVacations(searchEditText.getText().toString());
    }
}
